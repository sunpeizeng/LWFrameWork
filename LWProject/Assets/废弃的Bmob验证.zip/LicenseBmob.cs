﻿using cn.bmob.api;
using cn.bmob.io;
using Cysharp.Threading.Tasks;
using LWFramework.Core;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using UnityEngine;
namespace LWFramework.Core {
    public class LicenseBmob : BaseLicense
    {
        private BmobUnity bmobUnity;
        private LicenseTable licenseTable;
        private bool m_Load = false;
        public override void Init()
        {
            base.Init();
            GameObject gameObject = new GameObject();
            bmobUnity = gameObject.AddComponent<BmobUnity>();
            bmobUnity.ApplicationId = "6c1c92aeaa245ed2e69ad97bcb5b66f6";
            bmobUnity.RestKey = "c6a9f70af3aae95cb99e0df7e41eca55";
        }
        public async override UniTask Checking()
        {
            IsLicensePass = false;
            //创建一个BmobQuery查询对象
            BmobQuery query = new BmobQuery();
            //查询playerName的值为bmob的记录
            query.WhereEqualTo("ProdouctName", Application.productName);
            bmobUnity.Find<LicenseTable>("LicenseTable", query, (resp, exception) =>
            {
                m_Load = true;
                if (exception != null)
                {
                    LWDebug.LogError("错误");
                    //联网失败 用本地时间验证
                    int ret = DateTool.CompanyDate(DateTool.GetNowStr(), "2021年10月20日 00:00:00");
                    IsLicensePass = ret < 0;
                    return;
                }
                //对返回结果进行处理
                List<LicenseTable> list = resp.results;
                if (list.Count > 0) {
                    if (list[0].IsOpen == "1")
                    {
                        IsLicensePass = true;
                    }
                    licenseTable = list[0];
                   
                }
            });
            await UniTask.WaitUntil(() => m_Load);
            if (licenseTable != null) {
                licenseTable.UseCount = (int.Parse(licenseTable.UseCount) + 1).ToString();
                bmobUnity.Update("LicenseTable", licenseTable.objectId, licenseTable, (resp, exception) =>
                {
                    if (exception != null)
                    {
                        LWDebug.LogError("错误");
                    }
                    GameObject.Destroy(bmobUnity.gameObject);
                    bmobUnity = null;
                });
            }
          
        }
    }
    public class LicenseTable : BmobTable
    {
        /// <summary>
        /// 项目名称
        /// </summary>
        public string ProdouctName { get; set; }

        /// <summary>
        /// 使用次数
        /// </summary>
        public string UseCount { get; set; }

        /// <summary>
        /// 是否开启
        /// </summary>
        public string IsOpen { get; set; }

        public override void readFields(BmobInput input)
        {
            base.readFields(input);
            //读取属性值
            this.ProdouctName = input.getString("ProdouctName");
            this.UseCount = input.getString("UseCount");
            this.IsOpen = input.getString("IsOpen");
        }

        public override void write(BmobOutput output, bool all)
        {
            base.write(output, all);
            //写到发送端
            output.Put("ProdouctName", this.ProdouctName);
            output.Put("UseCount", this.UseCount);
            output.Put("IsOpen", this.IsOpen);
        }
    }
}
