﻿using UnityEngine;
using UnityEditor;
using System.Collections.Generic;
using System;
using Sirenix.OdinInspector;
using System.IO;

public enum LogColor
{
    red, yellow, blue, green, cyan, grey, white, _default
}
public enum LWLogLevel
{
    None = -1,Error = 0, Assert = 1, Warning = 2, All = 3
}
public class LWDebug {  
    
    public static void Log(object info, LogColor color=LogColor._default)
    {
        if (LWDebugMono.GetInstance().IsSelectLogType(LogType.Log)) {
            if (LWDebugMono.GetInstance().writeLog)
            {
                Debug.Log(info);               
            }
            else {
                Debug.Log(string.Format(GetHexByColor(color), info));
            }
            
        }      
    }

    public static void LogError(object info)
    {
        if (LWDebugMono.GetInstance().IsSelectLogType(LogType.Error))
            Debug.LogError(info);
    }
    public static void LogWarning(object info)
    {
        if (LWDebugMono.GetInstance().IsSelectLogType(LogType.Warning))
            Debug.LogWarning(info);
    }
    public static void SetLogConfig(bool lwGuiLog, int logLevel,bool writeLog) {
        LWDebugMono.GetInstance().lwGuiLog = lwGuiLog;
        LWDebugMono.GetInstance().logLevel = logLevel;
        LWDebugMono.GetInstance().writeLog = writeLog;
    }
    
    static string GetHexByColor(LogColor color) {
        string defaultHex = "<color=#000000ff>{0}</color>";
        
        switch (color)
        {
            case LogColor.red:
                defaultHex = "<color=#ff0000>{0}</color>";
                break;
            case LogColor.yellow:
                defaultHex = "<color=#ffff00ff>{0}</color>";
                break;
            case LogColor.blue:
                defaultHex = "<color=#0000ffff>{0}</color>";
                break;
            case LogColor.green:
                defaultHex = "<color=#008000ff>{0}</color>";
                break;
            case LogColor.cyan:
                defaultHex = "<color=#00ffffff>{0}</color>";
                break;
            case LogColor.grey:
                defaultHex = "<color=#808080ff>{0}</color>";
                break;
            case LogColor.white:
                defaultHex = "<color=#ffffffff>{0}</color>";
                break;
            case LogColor._default:

                defaultHex = "{0}";
                break;
            default:
                break;
        }
        return defaultHex;
    }
}

[DefaultExecutionOrder(-1000)]
public class LWDebugMono : MonoBehaviour
{
    private static LWDebugMono instance = null;
    //文件的路径
    private string path;
    [InfoBox("设置项3210-1,3:All,2:Warning,1:Assert,0:Error,-1:None不显示")]
    public int logLevel = 3;
    public bool writeLog = false;
    public bool lwGuiLog = true;

    private static GameObject m_LogObject;
    public static LWDebugMono GetInstance()
    {
        if (instance == null)
        {

            instance = FindObjectOfType<LWDebugMono>();
            if (instance == null)
            {
                m_LogObject = new GameObject();
                m_LogObject.name = typeof(LWDebugMono).Name;
                instance = m_LogObject.AddComponent<LWDebugMono>();
                DontDestroyOnLoad(m_LogObject);
            };
        }

        return instance;
    }

    string FileName {
        get {          
            return "logInfo" + DateTime.Now.ToString("yyyyMMddHH") + ".txt";
        }
    }
    void OnEnable()
    {
        if (path == null)
        {
            path = Application.persistentDataPath + "/";
        }
        skin = Resources.Load<GUISkin>("LogGUISkin");
        curLog = m_logAll;
        Application.logMessageReceivedThreaded += OnLogMessageReceivedThreaded;
        
    }
    void OnDisable()
    {
        if (m_LogObject != null) {
            GameObject.Destroy(m_LogObject);
        }
       // Application.logMessageReceivedThreaded -= OnLogMessageReceivedThreaded;
    }

    private void OnLogMessageReceivedThreaded(string condition, string stackTrace, LogType type)
    {
        LogInfo logInfo = new LogInfo(type, condition, stackTrace, DateTime.Now.ToString("yyyy年MM月dd日 HH:mm:ss"));
        switch (type)
        {
            case LogType.Warning:
                m_logWarning.Add(logInfo);
                break;
            case LogType.Log:
                m_logLog.Add(logInfo);
                break;
            case LogType.Error:
            case LogType.Exception:
                m_logError.Add(logInfo);
                break;
        }
        m_logAll.Add(logInfo);

       

       
        if (writeLog) {
            WriteToFile(FileName, logInfo.ToString(), path);
        }
    }
    
    //判断是否选择了该枚举值
    public bool IsSelectLogType(LogType _logType)
    {

        if ((int)_logType <= logLevel)
        {
            return true;
        }
        else {
            return false;
        }

       
    }  
    //错误详情
    public List<LogInfo> m_logAll = new List<LogInfo>();
    public List<LogInfo> m_logLog = new List<LogInfo>();
    public List<LogInfo> m_logWarning = new List<LogInfo>();
    public List<LogInfo> m_logError = new List<LogInfo>();
    public List<LogInfo> curLog = new List<LogInfo>();
    //是否显示错误窗口
    private bool m_IsVisible = false;
    //窗口显示区域
    private Rect m_WindowRect = new Rect(0, 20, Screen.width, Screen.height-20);
    //窗口滚动区域
    private Vector2 m_scrollPositionText = Vector2.zero;
    //字体大小
    private int fontSize = 30;
    GUISkin skin;
    void OnGUI()
    {
        if (!lwGuiLog) {
            return;
        }
        if (logLevel == -1) {
            return;
        }
        //GUIStyle fontStyle = new GUIStyle();
        //fontStyle.normal.background = new Texture2D(1,1); 
        if (GUI.Button(new Rect(Screen.width-30, 0, 30, 30), "", skin.customStyles[4]))
        {
            m_IsVisible = !m_IsVisible;
        }
        if (!m_IsVisible)
        {
            return;
        }
        m_WindowRect = GUILayout.Window(0, m_WindowRect, ConsoleWindow, "Console");
    }

    //日志窗口
    void ConsoleWindow(int windowID)
    {
        GUILayout.BeginHorizontal();
        skin.button.fontSize = fontSize;
        skin.textArea.fontSize = fontSize;      
        if (GUILayout.Button("Clear", skin.button, GUILayout.MaxWidth(120), GUILayout.MaxHeight(35)))
        {
            m_logAll.Clear();
        }      
        if (GUILayout.Button("Log", skin.button, GUILayout.MaxWidth(120), GUILayout.MaxHeight(35)))
        {
            if (curLog == m_logLog)
                curLog = m_logAll;
            else
                curLog = m_logLog;
        }
        if (GUILayout.Button("Warning", skin.button, GUILayout.MaxWidth(120), GUILayout.MaxHeight(35)))
        {
            if (curLog == m_logWarning)
                curLog = m_logAll;
            else
                curLog = m_logWarning;
        }
        if (GUILayout.Button("Error", skin.button, GUILayout.MaxWidth(120), GUILayout.MaxHeight(35)))
        {
            if (curLog == m_logError)
                curLog = m_logAll;
            else
                curLog = m_logError;
        }
        if (GUILayout.Button("Quit", skin.button, GUILayout.MaxWidth(120), GUILayout.MaxHeight(35)))
        {
            Application.Quit();
        }
        if (GUILayout.Button("+", skin.button, GUILayout.MaxWidth(120), GUILayout.MaxHeight(35)))
        {
            Debug.Log(SystemInfo.graphicsDeviceID + "-" + SystemInfo.graphicsDeviceVendorID + Application.productName);
        }
        GUILayout.EndHorizontal();
        m_scrollPositionText = GUILayout.BeginScrollView(m_scrollPositionText, skin.horizontalScrollbar, skin.verticalScrollbar);
        for (int i = 0; i < curLog.Count; i++)
        {
        
            Color currentColor = GUI.contentColor;
            switch (curLog[i].type)
            {
                case LogType.Warning:
                    GUI.contentColor = Color.white;
                    break;
                case LogType.Assert:
                    GUI.contentColor = Color.black;
                    break;
                case LogType.Log:
                    GUI.contentColor = Color.green;
                    break;
                case LogType.Error:
                case LogType.Exception:
                    GUI.contentColor = Color.red;
                    break;
            }
            if (GUILayout.Button(curLog[i].condition, skin.textArea))
            {
                curLog[i].isOpen = !curLog[i].isOpen;;
            }
            if (curLog[i].isOpen) {
                GUILayout.Label(curLog[i].stackTrace, skin.box);
            }
            
            GUI.contentColor = currentColor;
        }

       
        GUILayout.EndScrollView();
    }
    void WriteToFile(string fileFullName, string content, string dirPath)
    {
        string fileFullPath = Path.Combine(dirPath, fileFullName);
        FileInfo file = new FileInfo(fileFullPath);
        StreamWriter sw;
        sw = file.AppendText();
        //写入信息
        sw.WriteLine(content);
        sw.Flush();
        sw.Close();
    }
    public class LogInfo
    {
        public LogType type;
        public string condition;
        public string stackTrace;
        public string nowDate;
        public bool isOpen;

        public LogInfo(LogType type, string condition, string stackTrace, string nowDate)
        {
            this.type = type;
            this.condition = condition;
            this.stackTrace = stackTrace;
            this.nowDate = nowDate;
            isOpen = false;
        }
        public override string ToString()
        {
            return nowDate + "   " + type.ToString() + "：" + condition + "    ==>：" + stackTrace;
        }
    }
}
