﻿using Cysharp.Threading.Tasks;
using LWFramework.Core;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace LWFramework.Core {
    public class LicenseLocal : BaseLicense
    {
        private string m_EndTime = "2021年08月20日 00:00:00";
        private string m_NowTime;

        public override void Init()
        {
            base.Init();
            m_NowTime = DateTool.GetNowStr();

        }
        public async override UniTask Checking()
        {
            int ret = DateTool.CompanyDate(m_NowTime, m_EndTime);
            IsLicensePass = ret < 0;
            await UniTask.WaitForEndOfFrame();
        }
    }

}
