﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface IStepManager
{ 
    Action StepAllCompleted { get; set; }
    //IStep GetNextStepByIndex(int index);
    void StartStep();
    void MoveNext();
    void MovePrev();
    void JumpStep(int index);
    /// <summary>
    /// 设置数据
    /// </summary>
    /// <param name="data"></param>
    void SetData(object data);

    //void AddGameObject(string name, GameObject go);

    //GameObject GetGameObject(string name);

    //void ClearGameObject();
}
