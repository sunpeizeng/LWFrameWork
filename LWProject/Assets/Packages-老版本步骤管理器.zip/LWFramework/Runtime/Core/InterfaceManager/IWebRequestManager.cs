﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
namespace LWFramework.WebRequest {
    public interface IWebRequestManager
    {
        bool IsOffline { get; set; }

        void SendRequestUrl(string interfaceUrl, Action<string> handler, WWWForm form);
        void SendRequestUrlJson(string interfaceUrl, Action<string> handler, string parameter);
        void SendRequestUrl(string interfaceUrl, Action<string> handler);
        void SendRequestUrl(string interfaceUrl, Action<Texture2D> handler);
        void SendRequestUrl(string interfaceUrl, Action<AudioClip> handler);
        void SendRequestUrl(string interfaceUrl, Action<string> handler, params string[] parameter);
    }

}
