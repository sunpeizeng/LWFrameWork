﻿using Cysharp.Threading.Tasks;
using System;
using UnityEngine;
using Object = UnityEngine.Object;

public interface IAssetsManager
{  
    /// <summary>
    /// 加载资源
    /// </summary>
    /// <typeparam name="T">资源类型</typeparam>
    /// <param name="path">路径</param>
    /// <returns></returns>
    T Load<T>(string path);

    /// <summary>
    /// UniTask异步加载资源
    /// </summary>
    /// <typeparam name="T">资源类型</typeparam>
    /// <param name="path">路径</param>
    /// <returns></returns>
    UniTask<T> LoadAsync<T>(string path);

    /// <summary>
    /// 获取Request
    /// </summary>
    /// <typeparam name="T">返回异步操作的Request对象</typeparam>
    /// <typeparam name="K">返回的资源类型</typeparam>
    /// <param name="path">路径</param>
    /// <returns></returns>
    T GetRequest<T, K>(string path);

    /// <summary>
    /// 异步获取Request,在外部处理回调    
    /// </summary>
    /// <typeparam name="T">返回异步操作的Request对象</typeparam>
    /// <typeparam name="K">返回的资源类型</typeparam>
    /// <param name="path">路径</param>
    /// <returns></returns>
    T GetRequestAsync<T,K>(string path);

    /// <summary>
    /// 回调式异步加载场景
    /// </summary>
    /// <param name="scenePath"></param>
    /// <param name="additive">是否为添加</param>
    /// <param name="loadComplete">加载完成的回调</param>
    void LoadSceneAsync(string scenePath, bool additive, Action loadComplete = null);

    /// <summary>
    /// 获取SceneRequest,在外部处理回调    
    /// </summary>
    /// <typeparam name="T">返回异步操作的Request对象</typeparam>
    /// <param name="scenePath">场景的全路径</param>
    /// <param name="additive">是否为添加</param>
    /// <returns></returns>
    T GetSceneRequestAsync<T>(string scenePath, bool additive);

    /// <summary>
    /// 更新资源及加载场景（以场景名进行资源分包）
    /// </summary>
    /// <param name="scenePath"></param>
    /// <param name="additive">是否为添加</param>
    /// <param name="loadComplete">加载完成的回调</param>
    void UpdatePatchAndLoadSceneAsync(string scenePath, bool additive, Action loadComplete = null);

    /// <summary>
    /// 更新资源
    /// </summary>
    /// <param name="patchName">分包名称</param>
    /// <param name="loadComplete">加载完成的回调</param>
    void UpdatePatchAsset(string patchName, Action loadComplete = null);

    /// <summary>
    /// 释放资源
    /// </summary>
    /// <param name="param">Res-Object AB-Request</param>
    void Unload(object param); 
    /// <summary>
    /// 释放资源
    /// </summary>
    /// <param name="param">加载资源的路径</param>
    void Unload(string path);
    /// <summary>
    /// 将所有的引用全部释放 
    /// </summary>
    /// <param name="param">加载资源的路径</param>
    void UnloadAll(string path);
    /// <summary>
    /// 初始化更新回调 Res模式下为空
    /// </summary>
    Action<bool> OnInitUpdateComplete {  set; }


    /// <summary>
    /// 通过AB路径创建GameObject对象
    /// </summary>
    /// <param name="path">加载AB的路径</param>
    /// <returns>实例化的对象</returns>
    GameObject InstanceGameObject(string path);
    /// <summary>
    /// 通过AB路径创建GameObject对象
    /// </summary>
    /// <param name="path">加载AB的路径</param>
    /// <param name="parent">父物体</param>
    /// <param name="isWorld">是否世界坐标</param>
    /// <returns>实例化的对象</returns>
    GameObject InstanceGameObject(string path, Transform parent, bool isWorld);
    /// <summary>
    /// 异步通过AB路径创建GameObject对象
    /// </summary>
    /// <param name="path">加载AB的路径</param>
    /// <returns>实例化的对象</returns>
    UniTask<GameObject> InstanceGameObjectAsync(string path);
    /// <summary>
    /// 异步通过AB路径创建GameObject对象
    /// </summary>
    /// <param name="path">加载AB的路径</param>
    /// <param name="parent">父物体</param>
    /// <param name="isWorld">是否世界坐标</param>
    /// <returns>实例化的对象</returns>
    UniTask<GameObject> InstanceGameObjectAsync(string path, Transform parent, bool isWorld);
}
