﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LWFramework.Core;

namespace LWFramework.UI {
    /// <summary>
    /// 处理UI的逻辑,在View CreateView的时候处理的逻辑依次是 Logic构造函数->View获取UI组件->Logic OnCreate->View 自定义代码
    /// </summary>
    /// <typeparam name="TUIView"></typeparam>
    public class BaseUILogic <TUIView>: IUILogic where TUIView : class, IUIView
    {
        protected TUIView m_View;
        /// <summary>
        /// View的数据
        /// </summary>
        protected TableData m_ViewData;
        public BaseUILogic(TUIView p_View) {
            m_View = p_View;
            m_ViewData = ManagerUtility.UIMgr.ViewData;//new ViewData();
        }
        public virtual void OnCreateView() { }
        public virtual void OnOpenView() {
            m_ViewData.OnViewDataChange += OnViewDataChange;
        }
        public virtual void OnUpdateView() { 
        
        }
        public virtual void OnCloseView() {
            m_ViewData.OnViewDataChange -= OnViewDataChange;
        }
       
        public virtual void OnClearView() {
            OnCloseView();
            m_ViewData = null;
        }
        /// <summary>
        /// 内部处理ViewData中数据改变后的逻辑
        /// </summary>
        /// <param name="dataKey">改变的数值的key</param>
        protected virtual void OnViewDataChange(object dataKey) { }
    }
}

