﻿using Sirenix.OdinInspector;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using UnityEditor;
using UnityEngine;

[CreateAssetMenu(fileName = "UIEditConfig", menuName = "LWFramework/UIEditConfig", order = 0)]
public class UIEditConfig : ScriptableObject
{
    [LabelText("启动快速更换图片"),OnValueChanged("ChangeFastSelectImage")]
    public bool IsEnableFastSelectImage;

    [LabelText("快速更换图片自动设置大小")]
    public bool IsAutoSizeOnFastSelectImg;


    void ChangeFastSelectImage() {
        //选中Image节点并点击图片后即帮它赋上图片
        if (IsEnableFastSelectImage)
        {
            Selection.selectionChanged += UIEditorHelper.OnSelectChange;
        }
        else {
            Selection.selectionChanged -= UIEditorHelper.OnSelectChange;
        }    
    }


    [LabelText("缩放系数")]
    public string size = "";
    [Button("重设大小")]
    public void ResetSize()
    {
        float sizeValue = float.Parse(size);
        GameObject[] goArr = Selection.gameObjects;
        for (int i = 0; i < goArr.Length; i++)
        {
            RectTransform rectTransform = goArr[i].GetComponent<RectTransform>();
            if (rectTransform != null) {
                rectTransform.sizeDelta = new Vector2(rectTransform.sizeDelta.x * sizeValue, rectTransform.sizeDelta.y * sizeValue);
               // Undo.re
            }
            else
            {
                EditorWindow editorWindow = EditorWindow.GetWindow(typeof(SceneView));
                editorWindow.ShowNotification(new GUIContent("请先选择UI"));
            }
        }
       

    }
}
