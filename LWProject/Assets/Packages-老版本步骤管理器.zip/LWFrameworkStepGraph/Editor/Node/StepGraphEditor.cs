﻿using LWNode.LWStepGraph;
using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEditorInternal;
using UnityEngine;
using  XNodeEditor;

[CustomNodeGraphEditor(typeof(StepGraph))]
public class StepGraphEditor : NodeGraphEditor
{
    private float m_DeleyTime;
    private float m_DeleyTimeMax = 0.5f;
    private ReorderableList m_ObjectArray;
    public override string GetNodeMenuName(System.Type type)
    {
        if (type.Namespace == "LWNode.LWStepGraph")
        {            
            return base.GetNodeMenuName(type).Replace("LW Node/LW Step Graph/", "");
        }
        else return base.GetNodeMenuName(type);
    }

    public override void OnOpen()
    {
        base.OnOpen();
        m_ObjectArray = new ReorderableList(serializedObject, serializedObject.FindProperty("stringArray")
         , true, true, true, true);
        RefreshData();
    }
    public override void OnGUI()
    {
        base.OnGUI();
        GUI.Label(new Rect(10, 10, 90, 20), "陈斌");
        //LWDebug.Log(target);
        if (GUI.Button(new Rect(10, 40, 90, 20), "更新数据")) {
            
            StepGraph stepGraph = (StepGraph)target;
            for (int i = 0; i < stepGraph.nodes.Count; i++)
            {
               
                if (stepGraph.nodes[i] is StepNode) {
                    StepNode s = (StepNode)stepGraph.nodes[i];
                    s.EditSet();
                }
            }
           
        }
        m_DeleyTime -= Time.deltaTime;
        if (m_DeleyTime <= 0) {
            RefreshData();
            m_DeleyTime = m_DeleyTimeMax;
        }
    }
    void RefreshData() {
        StepGraph stepGraph = (StepGraph)target;
        for (int i = 0; i < stepGraph.nodes.Count; i++)
        {

            if (stepGraph.nodes[i] is StepNode)
            {
                StepNode s = (StepNode)stepGraph.nodes[i];
                s.EditSet();
            }
        }
    }
}
