﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/// <summary>
/// 步骤中的常用消息
/// </summary>
public class StepCommonMessage
{
    /// <summary>
    /// 发送帮助消息文字
    /// </summary>
    public static byte StepHelpMessage { get; }
}
