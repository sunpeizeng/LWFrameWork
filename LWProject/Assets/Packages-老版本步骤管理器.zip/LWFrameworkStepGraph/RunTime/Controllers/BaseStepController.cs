﻿using LWNode.LWStepGraph;
using Sirenix.OdinInspector;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Xml.Linq;
using UnityEngine;

/// <summary>
/// 步骤控制器，主要用于处理各种步骤中的变化效果
/// </summary>
[Serializable]
public abstract class BaseStepController:IStepController
{
    [LabelText("备注"),GUIColor(0,1,0)]
    public string m_Remark;

    protected Action m_ControllerExecuteCompleted;


    private StepNode m_CurrStepNode;
    /// <summary>
    /// 当前控制器执行完成的回调
    /// </summary>
    public Action ControllerExecuteCompleted { get => m_ControllerExecuteCompleted; set => m_ControllerExecuteCompleted = value; }
    public StepNode CurrNode { get => m_CurrStepNode; set => m_CurrStepNode = value; }
    public string Remark { get => m_Remark; }

    public abstract void ControllerBegin();
    public abstract void ControllerEnd();
    public abstract void ControllerExecute();

    public virtual void InputXml(XElement xElement)
    {
    }
    public virtual XElement ToXml()
    {
        XElement control = new XElement("Control");      
        return control;
    }
}
