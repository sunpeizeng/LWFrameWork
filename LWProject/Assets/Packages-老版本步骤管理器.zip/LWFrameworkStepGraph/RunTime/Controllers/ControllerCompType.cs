﻿using System;
using UnityEngine;
using Sirenix.OdinInspector;

/// <summary>
/// 组件控制类型
/// </summary>
public enum ControllerCompType
{    
   Add,
   Remove,
   None   
}
