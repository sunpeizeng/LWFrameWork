using LWFramework.Core;
using LWNode.LWStepGraph;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StepGraphManager : BaseStepManager ,IManager
{
    public override Action StepAllCompleted { get ; set ; }

    public override IStep CurrStepNode { get; set; }
    private StepGraph m_StepGraph;
    private int m_CurrIndex;
    //��ǰ�Ƿ�δ����첽
    private bool m_LastStep = false;
    public void Init()
    {

    }

    public void LateUpdate()
    {
    }

    public void Update()
    {

    }

    public override void SetData(object data) {
        m_StepGraph = (StepGraph)data;
    }
    public override void StartStep()
    {
        foreach (var item in m_StepGraph.nodes)
        {
            if (item.GetType() == typeof(StartNode))
            {
                StartNode startNode = (item as StartNode);
                startNode.m_StepManager = this;
                startNode.Start();
                m_CurrIndex = 0;
                break;
            }
            
        }
    }
    public override void JumpStep(int index)
    {
        while (m_CurrIndex != index) {
            if (m_CurrIndex > index && m_CurrIndex >= 0)
            {
                MovePrev();
            }
            else if (m_CurrIndex < index && m_LastStep == false)
            {
                MoveNext();
            }
            else {
                return;
            }
        }
    }

   

    public override void MoveNext()
    {
        CurrStepNode.StopTriggerList();
        CurrStepNode.StopControllerList();
        IStep stepNode = CurrStepNode.NextNode;
        if (stepNode != null)
        {
            stepNode.PrevNode = CurrStepNode;
            CurrStepNode = stepNode;
            CurrStepNode.StepManager = this;           
            stepNode.SetSelfCurrent();
            m_StepGraph.CurrStepNode = CurrStepNode;
            m_CurrIndex++;
        }
        else
        {
            StepAllCompleted?.Invoke();
            m_LastStep = true;
            LWDebug.Log("���һ��");
        }
    }

    public override void MovePrev()
    {
        CurrStepNode.StartControllerList(true);
        CurrStepNode.StopTriggerList();
        IStep stepNode = CurrStepNode.PrevNode;
        if (stepNode != null)
        {
            CurrStepNode = stepNode;
            CurrStepNode.StepManager = this;
            stepNode.StopControllerList();
            stepNode.SetSelfCurrent();

            m_StepGraph.CurrStepNode = CurrStepNode;
            m_CurrIndex--;
            m_LastStep = false;
        }
        else
        {
            LWDebug.Log("��һ��");
        }

    }


}
