using LWFramework.Core;
using LWNode.LWStepGraph;
using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class BaseStepManager : IStepManager
{
    private Dictionary<string, GameObject> m_GameObjectDict = new Dictionary<string, GameObject>();
    public abstract Action StepAllCompleted { get ; set ; }
    public abstract IStep CurrStepNode { get; set; }

    public abstract void SetData(object data);
    public abstract void StartStep();
    public abstract void JumpStep(int index);

    public abstract void MoveNext();

    public abstract void MovePrev();

    public void AddGameObject(string name, GameObject go)
    {
        if (!m_GameObjectDict.ContainsKey(name))
        {
            m_GameObjectDict.Add(name,go);
        }
        else {
            LWDebug.LogError($"������������Ѿ�������:{name} ����");
        }
    }

    public GameObject GetGameObject(string name)
    {
        GameObject ret = null;
        if (!m_GameObjectDict.TryGetValue(name,out ret)) {
            LWDebug.LogError($"�����������û�а���:{name} ����");
        }
        return ret;
    }

    public void ClearGameObject()
    {
        m_GameObjectDict.Clear();
    }
}
