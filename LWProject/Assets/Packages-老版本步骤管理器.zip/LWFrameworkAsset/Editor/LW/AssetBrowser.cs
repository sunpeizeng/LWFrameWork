﻿using libx;
using Sirenix.OdinInspector;
using Sirenix.OdinInspector.Editor;
using Sirenix.Utilities;
using Sirenix.Utilities.Editor;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEditor;
using UnityEngine;
[Searchable]
public class AssetBrowser : OdinEditorWindow
{
    public static AssetBrowser window;
    private static BuildRules m_BuildRules;
    [ TableList(ShowPaging = true, NumberOfItemsPerPage = 20,ShowIndexLabels = true)]
    public List<AssetBundleData> AssetBundleDataList = new List<AssetBundleData>();


  

    [MenuItem("LWFramework/资源浏览器", priority = 5)]
    public static void OpenWindow()
    {
        window = GetWindow<AssetBrowser>();
        window.position = GUIHelper.GetEditorWindowRect().AlignCenter(700, 700);
      
    }
    
    
    //[Button("查找")]
    //public void Find(string value) {
    //    if (value == "" || value ==null)
    //    {
    //        for (int i = 0; i < AssetBundleDataList.Count; i++)
    //        {
    //            AssetBundleDataList[i].UnChoose(); 

    //        }
    //    }
    //    else {
    //        for (int i = 0; i < AssetBundleDataList.Count; i++)
    //        {

    //            bool isFind = false;
    //            if (AssetBundleDataList[i].AssetBundleName.Contains(value))
    //            {
    //                AssetBundleDataList[i].Choose();
    //                continue;
    //            }
    //            else
    //            {
    //                for (int j = 0; j < AssetBundleDataList[i].AssetDataList.Count; j++)
    //                {
    //                    if (AssetBundleDataList[i].AssetDataList[j].AssetPath.Contains(value))
    //                    {
    //                        AssetBundleDataList[i].Choose();
    //                        isFind = true;
    //                        break;
    //                    }
    //                }
    //            }
    //            if (!isFind)
    //            {
    //                AssetBundleDataList[i].UnChoose();
    //            }
    //            else
    //            {
    //                continue;
    //            }
    //        }
    //    }
        
    //}
  
    [Button("刷新")]
    public void Refresh()
    {
        AssetBundleDataList.Clear();
        m_BuildRules = AssetDatabase.LoadAssetAtPath<BuildRules>("Assets/Rules.asset");

        for (int i = 0; i < m_BuildRules.bundles.Count; i++)
        {
            AssetBundleData assetBundleData = new AssetBundleData();
            BundleBuild bundleBuild = m_BuildRules.bundles[i];
            assetBundleData.AssetBundleName = bundleBuild.assetBundleName;
            assetBundleData.AssetDataList = new List<AssetData>();
            for (int j = 0; j < bundleBuild.assetNames.Count; j++)
            {
                AssetData assetData = new AssetData();
                assetData.Asset = AssetDatabase.LoadAssetAtPath<UnityEngine.Object>(bundleBuild.assetNames[j]);
                assetData.AssetPath = bundleBuild.assetNames[j];
                assetBundleData.AssetDataList.Add(assetData);
                
            }
            var fileInfo = new FileInfo(Environment.CurrentDirectory + "/" + BuildScript.outputPath + "/" + assetBundleData.AssetBundleName);
            var fileSize = fileInfo.Length;
            assetBundleData.Size = GetFormatSizeString((int)fileSize, 1024, "#,##0.##");

            AssetBundleDataList.Add(assetBundleData);
        }

    }

   
    public static string GetFormatSizeString(int size, int p, string specifier)
    {
        var suffix = new[] { "", "K", "M", "G", "T", "P", "E", "Z", "Y" };
        int index = 0;

        while (size >= p)
        {
            size /= p;
            index++;
        }

        return string.Format(
            "{0}{1}B",
            size.ToString(specifier),
            index < suffix.Length ? suffix[index] : "-"
        );
    }
}
[Serializable]
public class AssetBundleList {
    [TableList(ShowPaging = true, NumberOfItemsPerPage = 20, ShowIndexLabels = true)]
    public List<AssetBundleData> AssetBundleDataList = new List<AssetBundleData>();
}
[Serializable]
public class AssetBundleData
{
    [GUIColor("SetColor")]
    public string AssetBundleName;
    [TableColumnWidth(50,false),ReadOnly]
    public string Size;
    [TableList]
    public List<AssetData> AssetDataList;
    [HideInInspector]
    public bool isChoose;
    public void Choose() {
        isChoose = true;
    }
    Color SetColor() {
        if(isChoose)
            return Color.red;
        else
            return Color.white;
    }
    public void UnChoose() {
        isChoose = false;
    }
    [Button("Size"), TableColumnWidth(80, false)]
    public void SetSize()
    {

        for (int i = 0; i < AssetDataList.Count; i++)
        {
            var fileInfo = new FileInfo(Environment.CurrentDirectory + "/" + AssetDataList[i].AssetPath);
            var fileSize = fileInfo.Length;
            AssetDataList[i].Size = AssetBrowser.GetFormatSizeString((int)fileSize, 1024, "#,##0.##");

        }

      
    }
}
[Serializable]
public class AssetData {
    [TableColumnWidth(150, false)]
    public UnityEngine.Object Asset;
    [TableColumnWidth(50, false), ReadOnly]
    public string Size;
    [HideInInspector]
    public string AssetPath;
}