﻿using Cysharp.Threading.Tasks;
using libx;
using LWFramework.Core;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SceneAssetUtility 
{
    public static async UniTask<object> LoadScene_ShowBar(string scenePath, bool additive)
    {
        WidgetUIHelp.Instance.OpenLoadingBarView();
        WidgetUIHelp.Instance.SetAppVer(LWUtility.GlobalConfig.appVer);
        WidgetUIHelp.Instance.SetAssetVer(Assets.currentVersions.ver);
        SceneAssetAsyncRequest request =
            MainManager.Instance.GetManager<IAssetsManager>().GetSceneRequestAsync<SceneAssetAsyncRequest>(scenePath, additive);
        while (!request.isDone)
        {
            await UniTask.WaitForEndOfFrame();
            WidgetUIHelp.Instance.SetLoadingBarValue(Mathf.Clamp(request.progress / 0.32f, 0, 1));
        }
        await UniTask.WaitUntil(() => request.isDone);
        //打开UI界面
        WidgetUIHelp.Instance.CloseLoadingBarView();
        return null;
    }
    public static async UniTask<object> LoadScene_ShowLoading(string scenePath, bool additive)
    {
        WidgetUIHelp.Instance.OpenLoadingView();
        SceneAssetAsyncRequest request =
            MainManager.Instance.GetManager<IAssetsManager>().GetSceneRequestAsync<SceneAssetAsyncRequest>(scenePath, additive);
        
        await UniTask.WaitUntil(() => request.isDone);
       
        WidgetUIHelp.Instance.CloseLoadingView();
        return null;
    }
}
