﻿using libx;
using LWFramework.Core;
using LWFramework.UI;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading.Tasks;
using UnityEngine;

public class ABInitUpdate 
{
    private Action<bool> _onInitUpdateComplete;
    /// <summary>
    /// 初始化更新完成
    /// </summary>
    public Action<bool> OnInitUpdateComplete { get => _onInitUpdateComplete; set => _onInitUpdateComplete = value; }
    /// <summary>
    /// 是否自动更新
    /// </summary>
    private bool m_AutoUpdate { get; set; } = true;
   
    /// <summary>
    /// 更新进度条
    /// </summary>
    public GameObject m_ProgressBarGo { get; set; }
  //  private LoadingBarView m_LoadAssetBarView;
    /// <summary>
    /// 设置参数
    /// </summary>
    public void SetConfig() {
        LWGlobalConfig globalConfig = LWUtility.GlobalConfig;
        Assets.development = ((AssetMode)globalConfig.assetMode ==  AssetMode.AssetBundleDev);
        Assets.loggable = globalConfig.loggable;
        Assets.updateAll = globalConfig.updateAll;
        Assets.downloadURL = globalConfig.downloadURL;
        Assets.verifyBy = (VerifyBy)globalConfig.verifyBy;
        Assets.searchPaths = globalConfig.searchPaths;
        Assets.patches4Init = globalConfig.updatePatches4Init;
        m_AutoUpdate = globalConfig.autoCheckUpdate;
    }
    
    public virtual void AssetsInitialize() {

        Assets.Initialize(error =>
        {
            if (!string.IsNullOrEmpty(error))
            {
                Debug.LogError(error);
                return;
            }
            else
            {
                Debug.Log("Assets初始化成功");              
               // m_LoadAssetBarView = WidgetUIHelp.Instance.OpenLoadingBarView();
               // m_LoadAssetBarView.CloseView();
                //当下载地址为空的话，取本地数据
                if ((AssetMode)LWUtility.GlobalConfig.assetMode== AssetMode.AssetBundleLocal || Assets.downloadURL == "" || Assets.downloadURL==null) {

                    OnInitUpdateComplete?.Invoke(true);
                    return;
                }
                if (m_AutoUpdate)
                {
                    StartUpdate();
                }
                else {
                    WidgetUIHelp.Instance.OpenMessageBox("是否更新资源?", (flag) =>
                    {
                        if (flag)
                        {
                            StartUpdate();
                        }
                        else
                        {
                            Quit();
                        }
                    });
                }
            }
        });
    }

    public void StartUpdate()
    {
        if (Application.internetReachability == NetworkReachability.NotReachable)
        {
            WidgetUIHelp.Instance.OpenMessageBox( "请检查网络连接状态", retry =>
            {
                if (retry)
                {
                    StartUpdate();
                }
                else
                {
                    Quit();
                }
            },"警告提示", "重试", "退出");
        }
        else
        {
            Assets.DownloadVersions(error =>
            {
                if (!string.IsNullOrEmpty(error))
                {
                    WidgetUIHelp.Instance.OpenMessageBox( string.Format("获取服务器版本失败：{0}", error), retry =>
                    {
                        if (retry)
                        {
                            StartUpdate();
                        }
                        else
                        {
                            Quit();
                        }
                    }, "警告提示", "重试", "退出");
                }
                else
                {
                    UpdateAsset(Assets.patches4Init, "初始化更新", OnInitComplete);                    
                }
            });
        }
    }
    public void UpdateAsset(string []patchNameArray,string title,Action downloadCallback) {
        Downloader handler;
        // 按分包下载版本更新，返回true的时候表示需要下载，false的时候，表示不需要下载
        if (Assets.DownloadAll(patchNameArray, out handler))
        {
            var totalSize = handler.size;
            var tips = string.Format("需要下载 {0} 内容", Downloader.GetDisplaySize(totalSize));
            WidgetUIHelp.Instance.OpenMessageBox( tips, download =>
            {
                if (download)
                {
                    handler.onUpdate += delegate (long progress, long size, float speed)
                    {
                        //刷新界面
                        OnMessage(string.Format("下载中...{0}/{1}, 速度：{2}",
                            Downloader.GetDisplaySize(progress),
                            Downloader.GetDisplaySize(size),
                            Downloader.GetDisplaySpeed(speed)));
                        OnProgress(progress * 1f / size);
                    };
                    handler.onFinished += downloadCallback;
                    handler.onFinished += OnUpdateComplete;
                    handler.Start();
                    WidgetUIHelp.Instance.OpenLoadingBarView();
                }
                else
                {
                    Quit();
                }
            }, title, "确认", "退出");

        }
        else
        {
            downloadCallback?.Invoke();
            //OnUpdateComplete();
        }
    }
    private void OnProgress(float progress)
    {
        WidgetUIHelp.Instance.SetAppVer(LWUtility.GlobalConfig.appVer);
        WidgetUIHelp.Instance.SetAssetVer(Assets.currentVersions.ver);
        Debug.Log("更新进度：" + progress);
        WidgetUIHelp.Instance.SetLoadingBarValue(progress);
    }

    private void OnMessage(string msg)
    {
        Debug.Log(msg);
        WidgetUIHelp.Instance.SetLoadMsg(msg);
    }

    private void OnInitComplete()
    {
        OnProgress(1);
        if (Assets.currentVersions != null) {
            Debug.Log("资源版本：" + Assets.currentVersions.ver);
        }
        OnMessage("更新完成");
        OnInitUpdateComplete?.Invoke(true);
    }
    //更新结束
    private void OnUpdateComplete()
    {
        WidgetUIHelp.Instance.CloseLoadingBarView();
    }
    //退出程序
    private void Quit()
    {
        OnInitUpdateComplete?.Invoke(false);
#if UNITY_EDITOR && !CREATEDLL
        UnityEditor.EditorApplication.isPlaying = false;
#else
        Application.Quit();
#endif
    }
}
