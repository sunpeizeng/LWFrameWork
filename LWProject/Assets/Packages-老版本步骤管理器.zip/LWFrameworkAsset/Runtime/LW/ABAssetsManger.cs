﻿using libx;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using LWFramework.Core;
using Cysharp.Threading.Tasks;

public class ABAssetsManger : IAssetsManager,IManager
{
    private ABInitUpdate _abInitUpdate;
    public System.Action<bool> OnInitUpdateComplete { set => _abInitUpdate.OnInitUpdateComplete = value; }
    /// <summary>
    /// 自定义初始化更新器
    /// </summary>
    //public ABInitUpdate ABInitUpdate { set => _abInitUpdate = value; get => _abInitUpdate; }

    //所有的Request
    private Dictionary<string, AssetRequest> m_RequestDic;


    public void Init()
    {
        if (_abInitUpdate == null) {
            _abInitUpdate = new ABInitUpdate();
        }       
        _abInitUpdate.SetConfig();        
        m_RequestDic = new Dictionary<string, AssetRequest>();
        AssetsInitialize().Forget();
    }

    public void Update()
    {
    }
    public T Load<T>(string path)
    {
        AssetRequest request = Assets.LoadAsset(path, typeof(T));
        AddRequest(path, request);
        return (T)(object)request.asset;
    }
 
    public async UniTask<T> LoadAsync<T>(string path)
    {
        AssetRequest request = Assets.LoadAssetAsync(path, typeof(T));
        AddRequest(path, request);
        await UniTask.WaitUntil(() => request.isDone);
        
        return (T)(object)request.asset;
    }

   
    public void LoadSceneAsync(string scenePath,bool additive, System.Action loadComplete = null)
    {
        SceneAssetRequest sceneAssetRequest = Assets.LoadSceneAsync(scenePath, additive);
        sceneAssetRequest.completed = (asset) =>
        {
            loadComplete?.Invoke();
        };
       
    }
    
    public T GetRequest<T, K>(string path)
    {
        AssetRequest request = Assets.LoadAsset(path, typeof(K));
        AddRequest(path, request);
        return (T)(object)request;
    }
    //在外部使用awati处理异步 可以参考LoadAsync<T>(string path)
    public T GetRequestAsync<T,K>(string path)
    {
        AssetRequest request = Assets.LoadAssetAsync(path, typeof(K));
        AddRequest(path, request);
        return (T)(object)request;
    }
    //在外部使用awati处理异步
    public T GetSceneRequestAsync<T>(string scenePath, bool additive)
    {
        SceneAssetRequest sceneAssetRequest = Assets.LoadSceneAsync(scenePath, additive);
        return (T)(object)sceneAssetRequest;
    }
    public void Unload(object param)
    {
        AssetRequest request = ((AssetRequest)param);
        Unload(request.url);
    }
    public void Unload(string path) {
        AssetRequest request;
        if (m_RequestDic.TryGetValue(path, out request))
        {            
            request.Release();
            if (request.refCount <= 0) {
                m_RequestDic.Remove(path);
            }           
        }
    }
    public void UnloadAll(string path)
    {
        AssetRequest request;
        if (m_RequestDic.TryGetValue(path, out request))
        {
            while (request.refCount >0) {
                request.Release();               
            }
            m_RequestDic.Remove(path);
        }
    }
    public void UpdatePatchAndLoadSceneAsync(string scenePath, bool additive, System.Action loadComplete = null)
    {
        string patchName = scenePath.Substring(scenePath.LastIndexOf("/") + 1, (scenePath.LastIndexOf(".") - scenePath.LastIndexOf("/") - 1));
        _abInitUpdate.UpdateAsset(new[] { patchName }, "更新提示", () =>
        {
            SceneAssetRequest sceneAssetRequest = Assets.LoadSceneAsync(scenePath, additive);
            sceneAssetRequest.completed = (asset) =>
            {
                loadComplete?.Invoke();
            };          
        });
    }
    public void UpdatePatchAsset(string patchName, System.Action loadComplete = null)
    {
        _abInitUpdate.UpdateAsset(new[] { patchName }, "更新提示", () =>
        {
            loadComplete?.Invoke();
        });
    }
    /// <summary>
    /// 管理所有的Request
    /// </summary>
    /// <param name="path">加载的路径</param>
    /// <param name="request"></param>
    void AddRequest(string path, AssetRequest request)
    {
        if (!m_RequestDic.ContainsKey(path)) {
            m_RequestDic.Add(path, request);
        }       
    }

    /// <summary>
    /// 通过AB路径创建GameObject对象
    /// </summary>
    /// <param name="path">加载AB的路径</param>
    /// <returns>实例化的对象</returns>
    public GameObject InstanceGameObject(string path)
    {
        AssetRequest request = GetRequest<AssetRequest, GameObject>(path);
        GameObject go = Object.Instantiate(request.asset) as GameObject;
        request.Require(go);
        return go;
    }
    /// <summary>
    /// 通过AB路径创建GameObject对象
    /// </summary>
    /// <param name="path">加载AB的路径</param>
    /// <param name="parent">父物体</param>
    /// <param name="isWorld">是否世界坐标</param>
    /// <returns>实例化的对象</returns>
    public GameObject InstanceGameObject(string path, Transform parent, bool isWorld)
    {
        AssetRequest request = GetRequest<AssetRequest, GameObject>(path);
        GameObject go = Object.Instantiate(request.asset, parent, isWorld) as GameObject;
        request.Require(go);
        return go;
    }

    /// <summary>
    /// 异步通过AB路径创建GameObject对象
    /// </summary>
    /// <param name="path">加载AB的路径</param>
    /// <returns>实例化的对象</returns>
    public async UniTask<GameObject> InstanceGameObjectAsync(string path)
    {
        AssetRequest request = GetRequestAsync<AssetRequest, GameObject>(path);
        await UniTask.WaitUntil(() => request.isDone);
        GameObject go = Object.Instantiate(request.asset) as GameObject;
        request.Require(go);
       
        return go;
    }
    /// <summary>
    /// 异步通过AB路径创建GameObject对象
    /// </summary>
    /// <param name="path">加载AB的路径</param>
    /// <param name="parent">父物体</param>
    /// <param name="isWorld">是否世界坐标</param>
    /// <returns>实例化的对象</returns>
    public async UniTask<GameObject> InstanceGameObjectAsync(string path, Transform parent, bool isWorld)
    {
        AssetRequest request = GetRequestAsync<AssetRequest, GameObject>(path);
        await UniTask.WaitUntil(() => request.isDone);
        GameObject go = Object.Instantiate(request.asset, parent, isWorld) as GameObject;
        request.Require(go);
        return go;
    }
    //延迟5帧初始化，避免出现没有回调
    async UniTaskVoid AssetsInitialize()
    {       
        await UniTask.DelayFrame(5);
        _abInitUpdate.AssetsInitialize();
    }
}
